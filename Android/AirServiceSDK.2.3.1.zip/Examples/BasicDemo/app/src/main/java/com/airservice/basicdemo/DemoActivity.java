package com.airservice.basicdemo;

import android.os.Bundle;
import android.util.Log;

import com.airservice.airservicesdk.ASWebActivity;

import java.util.Map;

public class DemoActivity extends ASWebActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {

        clientID = "22c7d3fc";
        clientSecret = "aada245b93feb5d8e84dfeb49296da8b";
        appCollection = "airservice-qa-sdk";
        appEnvironment = ASEnvironment.QA;
        hostAction = ASHostActionType.Menu;

        super.onCreate(savedInstanceState);
    }

    @Override
    public void onCustomerUpdated(Map<Object, Object> payload) {
        Log.i("AirService", "Customer Details: " + payload.toString());
    }

//    @Override
//    public void onHostActionTriggered() {
//        Log.i("AirService", "onHostActionTriggered");
//        //user requested to leave AirService, perform necessary steps to close activity.
//        finish();
//    }
}
