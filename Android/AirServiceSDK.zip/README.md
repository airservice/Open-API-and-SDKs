# About AirServiceSDK

`AirServiceSDK` is provided as Android Libraries in the form of AAR files. With `AirServiceSDK`, you can easily add the `AirService Ordering` web app inside your own native app, and communicate with it in various ways.

If you're looking for iOS integration, please checkout our `AirServiceKit` for iOS.

# How to install

## Import AARs

`AirServiceSDK` for Android is provided as AAR files. They are located in `AirServiceSDK`:
 - Jockey: `jockey/jockey.aar
 - AirServiceSDK: `airservice/airservice.aar`.

 To integrate with your project in Android Studio you can either a) import the AARs as modules or b) compile them as dependencies:

### a) Import as modules

In `Android Studio`, click `File -> New Module -> Import .JAR/.AAR Package` and select the given `aar` files.

In your app's `build.gradle`, add:

```
dependencies {
    compile project(':jockey')
    compile project(':airservice')

    compile 'com.google.code.gson:gson:2.2.4'
    compile 'com.braintreepayments.api:braintree:2.+'
    compile 'com.braintreepayments.api:drop-in:2.+'
    compile 'com.google.android.gms:play-services-wallet:8.1.0'
    compile 'com.google.android.gms:play-services-location:8.1.0'
}
```

### b) Compile AARs

The method is demonstrated in the Examples/BasicDemo project.

In your app's `build.gradle`, add:

```
repositories {
    flatDir { dirs 'libs' }
}

dependencies {
    compile(name:'airservice', ext:'aar')
    compile(name:'jockey', ext:'aar')

    compile 'com.google.code.gson:gson:2.2.4'
    compile 'com.braintreepayments.api:braintree:2.+'
    compile 'com.google.android.gms:play-services-wallet:8.1.0'
    compile 'com.google.android.gms:play-services-location:8.1.0'
}
```

## Permissions

The following permissions will be merged to your app's manifest:

```xml
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE"/>
```

Braintree / PayPal related activities will be merged as well.

## Extend ASWebActivity

```
public class DemoActivity extends ASWebActivity { ... }
```

Which implements interface `ASWebInterface`:

```java
public interface ASWebInterface {
    /*
      Call 'public void notificationReceived(Bundle data)' when a notification is received while the application is running to show the customer ID page and other AirService messages.

      If the application is opened as a result of the user selecting the notification you can use this method to pass the notification content through to the AirServiceSDK once it is finished loaded by overriding 'onPageFinished()'.

      eg.
      @Override
      public void onPageFinished() {
          if (NotificationReceiver.message != null) {
            notificationReceived(NotificationReceiver.message.getPushBundle());
            NotificationReceiver.message = null;
          }
      }  
       */
    public void notificationReceived(Bundle data);

    /*
      Called when customer information is updated.
      User ID is unique and can be used in your own notification handler.
     */
    public void onCustomerUpdated(Map<Object, Object> payload);

    /*
    An optional method used to inform your application that the user has requested to exit AirService and return to your application.
    Depending on how your application implemented the launch of AirService you should use this delegate method to reverse that process.
    See ASHostActionType for supported types of return/exit buttons that will be shown.
     */
    public void onHostActionTriggered();

    /*
    When your application successfully registers for push notifications you must pass the device token
    through to your ASWebActivity subclass instance. This is so that AirService can use notifications
    to communicate order related messages to customers.
     */
    public static void addPushDeviceToken(Context context, String token);

    /*
    A string representation of the saved device token, if any, that AirServiceSDK currently holds.
    */
    public static String getPushDeviceToken(Context context)
}
```

# About the demo

In `Android Studio`, choose `File -> Import Project...`, and select `Examples/BasicDemo`.

# How to integrate

```java
    public void onCreate(Bundle savedInstanceState) {

        appCode         = "YOUR_APP_CODE"; //Your application code as provided by AirService
        clientID        = "YOUR_CLIENT_ID"; //Your client identifier for the AirService API
        clientSecret    = "YOUR_CLIENT_SECRET"; //Your client secret for the AirService API
        appCollection   = "YOUR_COLLECTION"; //Your collection name as provided by AirService
        appSector       = "YOUR_APP_SECTOR"; //Your sector name as provided by AirService. Depending on your setup by AirService this value may not be required.
        appVenueID      = "YOUR_APP_VENUE_ID"; //Your venue id as provided by AirService. Depending on your setup by AirService this value may not be required.

        super.onCreate(savedInstanceState);
	}
```

## GCM Notification

When an `AirService` related notification is received, please send it to your `ASWebActivity` so that order status can be handled using the `notificationReceived(Bundle data)` method. Please refer to `ASWebInterface` for details.

If your application also makes use of push notifications you can check the notification payload for the key/value pair "source":"airservice" and only pass the AirService specific notifications through to AirServiceSDK.

## Author

[www.github.com/airservice](www.github.com/airservice)

[www.airservice.com](www.airservice.com)
