//
//  MainViewController.h
//  whitelabel
//
//  Created by Daniel Bowden on 13/05/2014.
//  Copyright (c) 2014 AirService Digital Pty Ltd. All rights reserved.
//

#import "ASWhitelabelViewController.h"
#import <WatchConnectivity/WatchConnectivity.h>

extern NSString *const kASBeaconCollection;
extern NSString *const kASCustomerID;
extern NSString *const kASBeaconName;
extern NSString *const kASBeaconResponse;

@class MainViewController;

@protocol ASWebViewControllerDelegate<NSObject>
@optional - (void)ASWebViewControllerDidUpdateCustomer:(NSDictionary*)customer;
@optional - (void)ASWebViewControllerDidTriggerHostAction;
@end

@interface MainViewController : ASWhitelabelViewController<WCSessionDelegate >

@property (nonatomic, strong) IBInspectable NSString* clientID;
@property (nonatomic, strong) IBInspectable NSString* clientSecret;
@property (nonatomic, strong) IBInspectable NSString* collection;
@property (nonatomic, strong) IBInspectable NSString* appEnvironment;
@property (nonatomic, strong) IBInspectable NSString* filenameIcon;
@property (nonatomic, strong) IBInspectable NSString* hostAction;
@property (nonatomic) IBInspectable BOOL disablePayPal;

@property (nonatomic, strong) NSString* apiRoot;
@property (nonatomic, strong) NSString* schemePayPal;
@property (nonatomic, strong) NSDictionary* notification;
@property (nonatomic, strong) NSObject<ASWebViewControllerDelegate>* delegate;

- (void)sendPromotionDetailsToJockey:(NSDictionary*)dic;
- (void)sendPushToJockey:(NSDictionary*)dic;
- (void)requestCustomerDetails;
- (void)customerUpdated:(NSDictionary*)customer;
- (void)reload;
- (void)notificationReceived:(NSDictionary*)payload handler:(void (^)(UIBackgroundFetchResult))handler isLocal:(BOOL)isLocal;
- (BOOL)openURL:(NSURL*)url source:(NSString*)source;
+ (void)setLogging:(BOOL)logging;

@end