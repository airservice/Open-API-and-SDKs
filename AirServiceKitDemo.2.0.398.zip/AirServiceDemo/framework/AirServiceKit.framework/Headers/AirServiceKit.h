//
//  AirServiceKit.h
//  AirServiceKit
//
//  Created by Leo on 3/02/2016.
//  Copyright © 2016 AirService Digital. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for AirServiceKit.
FOUNDATION_EXPORT double AirServiceKitVersionNumber;

//! Project version string for AirServiceKit.
FOUNDATION_EXPORT const unsigned char AirServiceKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AirServiceKit/PublicHeader.h>

#import "bridging.h"

/*
#import <UAirship.h>

#import "AirServiceKit.h"
#import "MainViewController.h"
#import "ASAPIClient.h"
#import "ASLocationManager.h"
*/

#ifdef DEBUG
#	define DLog(...) NSLog(@"%s %@", __PRETTY_FUNCTION__, [NSString stringWithFormat:__VA_ARGS__])
#	define ALog(...) [[NSAssertionHandler currentHandler] handleFailureInFunction:[NSString stringWithCString:__PRETTY_FUNCTION__ encoding:NSUTF8StringEncoding] file:[NSString stringWithCString:__FILE__ encoding:NSUTF8StringEncoding] lineNumber:__LINE__ description:__VA_ARGS__]
#else
#	define DLog(...) do { } while (0)
#	ifndef NS_BLOCK_ASSERTIONS
#		define NS_BLOCK_ASSERTIONS
#	endif
#	define ALog(...) NSLog(@"%s %@", __PRETTY_FUNCTION__, [NSString stringWithFormat:__VA_ARGS__])
#endif

