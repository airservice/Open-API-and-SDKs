import AirServiceKit//
//  ViewController.swift
//  AirServiceKitExample
//
//  Created by Leo on 4/02/2016.
//  Copyright © 2016 AirService Digital. All rights reserved.
//

import UIKit
import MapKit

struct My {
	static var app: AppViewController?
	static var tab: MyTabBarController!
	static var airservice: MyAirServiceViewController?
	static var delegate: AppDelegate?
	static var notification: [NSObject: AnyObject]?
}

class AppViewController: UIViewController, CLLocationManagerDelegate {

	@IBOutlet var labelLocation: UILabel!
	@IBOutlet var labelNotification: UILabel!

	var locationManager = CLLocationManager()
	
	override func viewDidLoad() {
		super.viewDidLoad()
		My.app = self
		locationStart()
		print("LOCATION started")
	}

	override func didReceiveMemoryWarning() {
		super.didReceiveMemoryWarning()
	}
	
	//	location
	func locationStart() {
		locationManager.desiredAccuracy = kCLLocationAccuracyBest
		locationManager.delegate = self
		locationManager.requestWhenInUseAuthorization()
		locationManager.startUpdatingLocation()
	}
	func locationManager(manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
		labelLocation.text = locations.description
		//print("LOCATION updated \(locations)")
	}
	func locationManager(manager: CLLocationManager, didFailWithError error: NSError) {
		labelLocation.text = error.localizedDescription
		print("LOCATION error \(error)")
	}
}

class MyTabBarController: UITabBarController {
	override func viewDidLoad() {
		super.viewDidLoad()
		My.tab = self
	}
}

class MyAirServiceTab1ViewController: MyAirServiceViewController  {
	override func viewDidLoad() {
		super.viewDidLoad()
	}
}

class MyAirServiceTab2ViewController: MyAirServiceViewController  {
	override func viewDidLoad() {
		super.viewDidLoad()
	}
	override func viewWillAppear(animated: Bool) {
		super.viewWillAppear(animated)
		My.tab.tabBar.hidden = true
		view.frame = My.tab.view.frame
	}
	func ASWebViewControllerDidTriggerHostAction() {
		if (My.tab.tabBar.hidden) {
			My.tab.tabBar.hidden = false
			view.frame = CGRectMake(
				view.frame.origin.x,
				view.frame.origin.y,
				view.frame.size.width,
				view.frame.size.height - 50)
		}
	}
}

class MyAirServiceNavPushViewController: MyAirServiceViewController {
	func ASWebViewControllerDidTriggerHostAction() {
		navigationController?.popViewControllerAnimated(true)
	}
}

class MyAirServiceNavPresentViewController: MyAirServiceViewController {
	func ASWebViewControllerDidTriggerHostAction() {
		dismissViewControllerAnimated(true, completion:nil)
	}
}

class MyAirServiceViewController: ASWebViewController, ASWebViewControllerDelegate {

	override func viewDidLoad() {
		filenameIcon = "AirService"
		disablePayPal = false
		super.viewDidLoad()
		My.airservice = self
		delegate = self
		if let notification = My.notification {
			self.notification = notification
			My.notification = nil
		}
		navigationController?.navigationBarHidden = true
		//UIApplication.sharedApplication().statusBarHidden = true
		edgesForExtendedLayout = .None 
	}
	override func viewWillAppear(animated: Bool) {
		super.viewWillAppear(animated)
		//navigationController?.setNavigationBarHidden(true, animated: false)
	}
	override func viewWillDisappear(animated: Bool) {
		super.viewWillDisappear(animated)
		//navigationController?.setNavigationBarHidden(false, animated: false)
		navigationController?.navigationBarHidden = false
		//UIApplication.sharedApplication().statusBarHidden = false
	}

	//	MARK: ASWebViewControllerDelegate
	func ASWebViewControllerDidUpdateCustomer(customer: [NSObject: AnyObject]) {
		print("AIRSERVICE customer updated: \(customer)")
	}
}
