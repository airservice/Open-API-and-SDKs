package com.airservice.airservicesdkdemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.airservice.airservicesdk.ASWebActivity;

public class DemoActivity extends ASWebActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        clientID = "YOUR_CLIENT_ID";
        clientSecret = "YOUR_CLIENT_SECRET";
        appCollection = "YOUR_COLLECTION";
        appCollection = "YOUR_SECTOR_OPTIONAL";

        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_demo);
    }
}