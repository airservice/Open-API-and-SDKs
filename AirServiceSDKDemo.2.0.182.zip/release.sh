#!/bin/bash

echo --- Cloning whitelabel...
mkdir -p tmp
git clone git@github.com:airservice/ordering_whitelabel_android.git tmp/whitelabel
cd tmp/whitelabel
# test only
# git checkout refactor/library_pt112863213

echo --- Building whitelabel...
cp ~/prj/ordering_whitelabel_android/gradle.properties .
./gradlew :airservicesdk:build
./gradlew :jockeyJSAndroid:build
cp airservicesdk/build/outputs/aar/airservicesdk-release.aar ../../airservice/airservice.aar
cp jockeyJSAndroid/build/outputs/aar/jockeyJSAndroid-release.aar ../../jockey/jockey.aar

rev=$(command git rev-list HEAD | wc -l | tr -d ' ')
# TODO: get version code from build.gradle
ver=2.0.$rev
echo --- Releasing $ver
git tag sdk.$ver -f
git push -f origin sdk.$ver
cd ../..
rm -rf tmp
zip -r AirServiceSDKDemo.$ver.zip . -x *.git*
git tag $ver -f
git push -f origin $ver
buildkite-agent artifact upload AirServiceSDKDemo.$ver.zip