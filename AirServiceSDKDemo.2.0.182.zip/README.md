# About AirServiceSDK

`AirServiceSDK` is provided as Android Libraries in the form of AAR files. With `AirServiceSDK`, you can easily add the `AirService Ordering` web app inside your own native app, and communicate with it in various ways.

If you're looking for iOS integration, please checkout our `AirServiceKit` for iOS.

# How to install

## Import AARs

`AirServiceSDK` for Android is provided as AAR files. They are located in `AirServiceSDKDemo`:
 - Jockey: `jockey/jockey.aar
 - AirServiceSDK: `airservice/airservice.aar`.

In `Android Studio`, click `File -> New Module -> Import .JAR/.AAR Package` and select the given `aar` files.

## Add dependencies

In `build.gradle`, add:

```
    compile project(':jockey')
    compile 'com.google.code.gson:gson:2.2.4'

    compile project(':airservice')
    compile 'com.braintreepayments.api:braintree:2.+'
    compile 'com.braintreepayments.api:drop-in:2.+'
    compile 'com.google.android.gms:play-services-wallet:8.1.0'
    compile 'com.google.android.gms:play-services-location:8.1.0'
	compile 'org.altbeacon:android-beacon-library:2.7.1'
```

## Permissions

The following permissions will be merged to your app's manifest:

```
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.CALL_PHONE"/>
```

Braintree / PayPal related activities will be merged as well.

## About iBeacon Discovery

If background mode is enabled for an AirService collection, an iPad that's running `AirService Terminal` can be turned into an iBeacon emitter so that app users will be receiving promotion info etc. via notification when they enter the beacon region.

### Requirements

Permissions: android.permission.BLUETOOTH_ADMIN, android.permission.BLUETOOTH
API level: android-18 (4.3)

### Launch activity

An activity needs to be provided so that once the beacon notification is tapped, this activity will be launched.

- Manifest: add `android:launchMode="singleInstance"` to your activity.
- Create your own application class: `android:name="com.yourapp.WhitelabelApplication"`
- Extend `ASApplication`: `public class WhitelabelApplication extends ASApplication ...`
- Add in `onCreate`: `airserviceClass = WhitelabelActivity.class;`

## Extend ASWebActivity

```
public class DemoActivity extends ASWebActivity { ... }
```

Which implements interface `ASWebInterface`:

```
public interface ASWebInterface {
    /*
      Call 'sendPush(notification)' on 'page finished' to show ID page when notification is received.
      If it's handled it in your own activity, you don't need to do anything with this method.
       */
    public void onPageFinished();
    /*
      Called when customer information is updated.
      User ID is unique and can be used in your own notification handler.
     */
    public void onCustomerUpdated(Map<Object, Object> payload);
}
```

Then start `DemoActivity` to show the `AirService` app.

# About the demo

In `Android Studio`, choose `File -> Import Project...`, and select `AirServiceSDKDemo`.

# How to integrate

```
    public void onCreate(Bundle savedInstanceState) {

        clientID        = "YOUR_CLIENT_ID";
        clientSecret    = "YOUR_CLIENT_SECRET";
        appCollection   = "YOUR_COLLECTION";

        super.onCreate(savedInstanceState);
		...
	}
```

## GCM Notification

When an `AirService` related notification is received, please send it to your `ASWebActivity` so that order status can be handled. Please refer to `ASWebInterface` for details.

### Ordering

- User logs in and makes order
	- `AirService` user ID is related with `Urban Airship` user alias
	- `AirService` user ID can be accessed via interface method `onCustomerUpdated(map)`
	- TODO: a callback `order_placed` can be added if needed
- Terminal accepts order and informs user when it's ready
	- `AirService` sends push to alias via `Urban Airship`
	- TODO: `AirService` calls webhook `https://yoursite.com/api/order_ready` so that GCM notification can be sent via `yoursite.com`
- Notification is received and handled by `ASWebViewController` or the parent app
	- Call `sendPush(notification)` to present user ID page inside the `AirService` web app
	- Or start a native `Activity` with updated user info in the parent app

### Region monitoring & iBeacon

Not implemented in Android apps yet.

### TODO

Notification payload formats should be defined here.

# Version history

- 2.0.182: added `appSector` parameter and internal iBeacon support
- 2.0.166: public beta
- 1.0.165: initial release with QA credential - it should be used for internal testing only