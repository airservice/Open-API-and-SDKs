import AirServiceKit//
//  AppDelegate.swift
//  AirServiceKitExample
//
//  Created by Leo on 4/02/2016.
//  Copyright © 2016 AirService Digital. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

	var window: UIWindow?

	func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
		My.delegate = self

		//	Creating ASWebViewController by code. You can also do it via
		//	storyboard - see MyAirServiceViewController as an example.
		/*
		let controllerAirService = ASWebViewController()

		//	required
		controllerAirService.clientID		= "YOUR_CLIENT_ID"
		controllerAirService.clientSecret	= "YOUR_CLIENT_SECRET"
		controllerAirService.collection		= "YOUR_COLLECTION"
		controllerAirService.reload()

		//	override storyboard setting
		if let window = window {
			window.rootViewController = controllerAirService
		}
		*/
		ASWebViewController.setLogging(false)

		//	init push
		let settings = UIUserNotificationSettings(forTypes: [.Alert, .Badge, .Sound], categories: nil)
		UIApplication.sharedApplication().registerUserNotificationSettings(settings)
		UIApplication.sharedApplication().registerForRemoteNotifications()
		print("PUSH inited")
		//	Or use 3rd party services like UrbanAirship

		//	You can design how you're going to send remote notification to
		//	ASWebViewController to open the ID page. Of course you can also
		//	create an ID page and handle it in your app.
		if let notification = launchOptions?[UIApplicationLaunchOptionsRemoteNotificationKey] as? [NSObject: AnyObject] {
			print("PUSH launched with remote notification: \(notification)")
			My.notification = notification
		} 

		return true
	}

	//	MARK: push notification
	func application(application: UIApplication,didRegisterForRemoteNotificationsWithDeviceToken token: NSData) {
		var s = token.description
			.stringByReplacingOccurrencesOfString("<", withString:"")
			.stringByReplacingOccurrencesOfString(">", withString:"")
			.stringByReplacingOccurrencesOfString(" ", withString:"")
		s = "PUSH registered \(s)"
		My.app?.labelNotification.text = s
		print(s)
	}
	func application(application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: NSError) {
		let s = "PUSH registered \(error)"
		My.app?.labelNotification.text = s
		print(s)
	}
	func application(app: UIApplication, didReceiveRemoteNotification info: [NSObject: AnyObject]) {
		handleNotification(info)
	}
	func application(app: UIApplication, didReceiveRemoteNotification info: [NSObject: AnyObject], fetchCompletionHandler handler: (UIBackgroundFetchResult) -> Void) {
		handleNotification(info, handler: handler)
	}

	//	local notification is used for iBeacon promotion
	func application(app: UIApplication, didReceiveLocalNotification notification: UILocalNotification) {
		if let info = notification.userInfo {
			handleNotification(info, isLocal: true)
		}
	}

	func handleNotification(info: [NSObject: AnyObject], handler: (((UIBackgroundFetchResult) -> Void)?) = nil, isLocal: Bool = false) {
		let s = "PUSH received: \(info)"
		My.app?.labelNotification.text = s
		if let airservice = My.airservice {
			airservice.notificationReceived(info, handler: handler, isLocal: isLocal)
		} else {
			print(s)
			handler?(.NoData)
		}
	}

	//	MARK: UIApplicationDelegate
	func application(application: UIApplication, openURL url: NSURL, sourceApplication: String?, annotation: AnyObject) -> Bool {
		//	Process URLs like com.yourapp.payments to open the PayPal app if
		//	it's installed. The following check is not necessary as it's built
		//	in airservice.openURL as well.
		if let airservice = My.airservice where url.scheme.localizedCaseInsensitiveCompare(airservice.schemePayPal) == .OrderedSame {    
			return airservice.openURL(url, source: sourceApplication)
		}
		return false
	}
	
	func applicationWillResignActive(application: UIApplication) {
	}

	func applicationDidEnterBackground(application: UIApplication) {
	}

	func applicationWillEnterForeground(application: UIApplication) {
	}

	func applicationDidBecomeActive(application: UIApplication) {
		//	add your app version enforcer here
	}

	func applicationWillTerminate(application: UIApplication) {
	}
}
