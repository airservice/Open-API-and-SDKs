# About AirServiceKit

`AirServiceKit` is provided as a `Cocoa Touch Framework` which requires iOS 8.0 or above. With `AirServiceKit`, you can easily add the `AirService Ordering` web app inside your own native app, and communicate with it in various ways.

If you're looking for Android integration, please checkout our `AirServiceSDK` for Android.

# How to install

`AirServiceKit.framework` has been built based for 2 kinds of architectures: `arm64 / armv7` and `x86_64`: `arm` is used for device build and `x86` is used for simulator. They are stored in the `framework` directory. Simply drag and drop the right version into your Xcode project or workspace and choose `Your Target -> General -> Embedded Binaries -> Add` and you're good to go. You may also like to edit your `Info.plist` file to enable some of the functionailities provided.

# About the demo

To run `AirServiceDemo`, please **replace** `framework/AirServiceKit.framework` with the one in `arm` or `x86` to run it on device or simulator. You can also double-click the `use_fat_framework.command` file to create and use combined "fat framework", but when you submit your app to iTunesConnect, please replace it with the one in `arm`, otherwise the uploading process will fail eventually.

Please refer to the `Info.plist` file of `AirServiceDemo` for the example values. Keys are listed here with explanation:

- `App Transport Security Settings`: `Allow Arbitrary Loads` needs to be turned on to `YES` so that the web app can load properly.
- `URL types` and `LSApplicationQueriesSchemes`: to support adding `PayPal` account from the native `PayPal` app.
- `NSLocationWhenInUseUsageDescription`: venue searching.
- `NSLocationAlwaysUsageDescription` and `Required background modes`: geo region monitoring, and iBeacon promotion discovery.
- `Supported interface orientations` and `Supported interface orientations (iPad)`: landscape mode is not well supported currently.

# How to integrate

Please refer to `Main.storyboard`, `AppDelegate.swift` and `ViewController.swift` in `AirServiceDemo` for the working demo.

## AppViewController

In this view controller, you can use `CLLocationManager` as usual. Please note that if you're using geo `region monitoring` and `iBeacon promotion` discovery from `AirService`, you need to *be careful when accessing your `locationManager.monitoredRegions`* since they are shared accross the app. Please refer to Apple's [Region Monitoring and iBeacon](https://developer.apple.com/library/ios/documentation/UserExperience/Conceptual/LocationAwarenessPG/RegionMonitoring/RegionMonitoring.html) for details.

## MyAirServiceController

### Adding ASWebViewController to your project

To embed an `AirService` web app into your own app, please make an instance of `ASWebViewController` - you can push, present, or add it into your `UINavigationController`, `UITabViewController`, etc. *Currently only one `ASWebViewController` can be in the same app.*

You can add it in your `Storyboard` by changing the class of a `View Controller` to `ASWebViewController`. In the demo we use a subclass `MyAirServiceViewController` to add in-app notification handling and view resizing, but you don't always have to subclassing `ASWebViewController`.

You can also create a `ASWebViewController` from code. See the commented code in `AppDelegate` for details. In general, `clientID`, `clientSecret`, and `collection` are required to load `ASWebViewController`, while `sector` can be left empty for some collections. It tries to load from the order below:

- In `Interface Builder`, create a view controller and change its class to `ASWebViewController` or a subclass of it. You'll be able to edit these properties directly as `IBInspectable`.
- You can also load the properties from code, e.g. `controllerAirService.clientID = "YOUR_CLIENT_ID"`. See the commented code in `AppDelegate` for details.
- Before `viewDidLoad` of `ASWebViewController` is called, it tries to load `ASClientID`, `ASClientSecret`, and `ASAppCollection` from `Info.plist`.

### UI design guideline

As a view controller, `ASWebViewController` can be embedded as a tab bar, or be pushed or presented in a parent navigation controller. Since `AirService` web app provites an integrated user experence, it is recommended to show the app in full screen mode, i.e. hide your navigation bar, tab bar, etc.

To get back to your app, set the `host_action` property to `back`, `close`, `menu`, or `home`. If it's set, a "host" button will be added to our web app in the top left corner, and once it's tapped, a delegate method `ASWebViewControllerDidTriggerHostAction` will be called. The icon of the button is called based on the value of `host_action`.

## AppDelegate

### ASWebViewControllerDelegate

When a user logs in to `AirService`, a delegate method will be called with customer information, including name, ID, contact, etc.

```
	func ASWebViewControllerDidUpdateCustomer(customer: [NSObject: AnyObject]) {
		print("AIRSERVICE customer updated: \(customer)")
	}
```

When the host button is tapped, a delegate method will be called so that you can choose to hide or dismiss the current `ASWebViewController`.

```
	func ASWebViewControllerDidTriggerHostAction() {
		//navigationController?.popViewControllerAnimated(true)
		//dismissViewControllerAnimated(true, completion:nil)
	}
```

### Supporting the native PayPal app

Other than adding key/values in `Info.plist`, the following code is also required to support the native PayPal app. With all these implemented, if a user has the PayPal installed on his phone, he can add his PayPal account as a payment method into `AirService` platform directly.

```
	func application(application: UIApplication, openURL url: NSURL, sourceApplication: String?, annotation: AnyObject) -> Bool {
		return airservice.openURL(url, source: sourceApplication)
	}
```

### Other parameters

```
//	Disable PayPal as a payment method
disablePayPal = true
//	Set loading icon
filenameIcon = "AirService"
```

### misc FIXME

- filenameIcon may fail if image is in one of the `xcassets
- Please always disable logging after app is launched.
```
	ASWebViewController.setLogging(false)
```

## Push Notification

When an `AirService` related push notification is received, please send it to `ASWebViewController` so that iBeacon promotion, region monitoring, and order status can be handled.

```
	airserviceViewController.notificationReceived(info, handler: handler, isLocal: isLocal)
```

### Ordering

- User logs in and makes order
	- `AirService` user ID is related with `Urban Airship` user alias
	- `AirService` user ID can be accessed via delegate method `ASWebViewControllerDidUpdateCustomer`
	- TODO: a callback `order_placed` can be added if needed
- Terminal accepts order and informs user when it's ready
	- `AirService` sends push to alias via `Urban Airship`
	- TODO: `AirService` calls webhook `https://yoursite.com/api/order_ready` so that push notification can be sent via `yoursite.com`
- Notification is received and handled by `ASWebViewController` or the parent app
	- Call `notificationReceived` to present user ID page inside the `AirService` web app
	- Or present a native `ViewController` with updated user info in the parent app

### Region monitoring & iBeacon

- Enable background location update and various background modes in the parent app
- `AirServiceKit` handles region monitoring and inform `AirService` with events like `device/region/entered`, `collection/promotions` etc.
- TODO: `AirService` calls webhook `https://yoursite.com/api/venue_available` when events are triggered and nearby venues or promotions are found

### TODO

Notification payload formats should be defined here.

# Version history

- 2.0.400
  - fixed an issue that prevents custom info to be updated
- 2.0.398
  - added script to create fat framework for easy development
- 2.0.396
  - added support for multiple instances
  - added sector as a parameter
- 1.0.375
  - app info can be set in `Info.plist` now
  - added support for loading icon
  - added a flag to disable paypal (enabled by default)
- 1.0: initial release, internal testing only